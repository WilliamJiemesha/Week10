from flask import Flask, render_template, url_for, redirect, session, request, flash
from datetime import timedelta

app = Flask(__name__)
app.secret_key = "MichaelSusanjim"
app.permanent_session_lifetime = timedelta(days=5)

@app.route('/')
def homepage():    
    if "username" in session:
        return render_template('homepage.html', nama=session['username'])
    else:
        return render_template('homepage.html')

@app.route('/login', methods=["POST", "GET"])
def loginpage():
    if "username" in session:
        return redirect(url_for('homepage'))
    else:
        if request.method == "POST":
            session.permanent = True
            username = request.form['usernamelogin']
            password = request.form['passwordlogin']
            if username == password:
                session["username"] = username                                
                return redirect(url_for('homepage'))
            else:                
                flash('Username atau Password Salah!')
                return render_template('login.html')
        else:
            return render_template('login.html')        

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('homepage'))

@app.route('/normal')
def normal():
    if "username" in session:
        return redirect(url_for('special'))
    else:
        return render_template('normalpage.html')

@app.route('/special')
def special():
    if "username" in session:
        return render_template('specialpage.html')
    else:
        return redirect(url_for('homepage'))

if __name__ == '__main__':
    app.run()